import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { 
  User, UserRole, UserStatus, 
  Project, ProjectStatus, ProjectMember,
  Task, TaskStatus, TaskPriority,
  TaskComment, TaskAttachment, 
  Notification, ActivityLog, DashboardStats 
} from '../src/types.js';

const DB_FILE = path.join(process.cwd(), 'database.json');

interface Schema {
  users: User[];
  passwords: Record<string, string>; // userId -> bcrypt hash
  projects: Project[];
  projectMembers: ProjectMember[];
  tasks: Task[];
  taskComments: TaskComment[];
  taskAttachments: TaskAttachment[];
  notifications: Notification[];
  activityLogs: ActivityLog[];
}

// Default state with seeds
const getInitialSchema = (): Schema => {
  const salt = bcrypt.genSaltSync(10);
  const defaultPasswordHash = bcrypt.hashSync('password123', salt);

  const users: User[] = [
    {
      id: 'usr-admin',
      email: 'admin@example.com',
      fullName: 'Chief Administrator',
      role: UserRole.ADMIN,
      status: UserStatus.ACTIVE,
      createdAt: new Date('2026-06-01T09:00:00Z').toISOString()
    },
    {
      id: 'usr-pm',
      email: 'pm@example.com',
      fullName: 'Sarah Jenkins',
      role: UserRole.PROJECT_MANAGER,
      status: UserStatus.ACTIVE,
      createdAt: new Date('2026-06-02T10:00:00Z').toISOString()
    },
    {
      id: 'usr-alice',
      email: 'alice@example.com',
      fullName: 'Alice Smith',
      role: UserRole.TEAM_MEMBER,
      status: UserStatus.ACTIVE,
      createdAt: new Date('2026-06-03T09:30:00Z').toISOString()
    },
    {
      id: 'usr-bob',
      email: 'bob@example.com',
      fullName: 'Bob Jones',
      role: UserRole.TEAM_MEMBER,
      status: UserStatus.ACTIVE,
      createdAt: new Date('2026-06-03T11:00:00Z').toISOString()
    },
    {
      id: 'usr-charlie',
      email: 'charlie@example.com',
      fullName: 'Charlie Brown',
      role: UserRole.TEAM_MEMBER,
      status: UserStatus.INACTIVE,
      createdAt: new Date('2026-06-04T14:00:00Z').toISOString()
    }
  ];

  const passwords: Record<string, string> = {
    'usr-admin': defaultPasswordHash,
    'usr-pm': defaultPasswordHash,
    'usr-alice': defaultPasswordHash,
    'usr-bob': defaultPasswordHash,
    'usr-charlie': defaultPasswordHash
  };

  const projects: Project[] = [
    {
      id: 'prj-alpha',
      name: 'E-Commerce Platform Redesign',
      description: 'Complete overhaul of the consumer shopping experience, optimizing checkout flows, visual themes, and page loading speed.',
      startDate: '2026-06-15',
      endDate: '2026-08-15',
      status: ProjectStatus.IN_PROGRESS,
      managerId: 'usr-pm',
      progressPercentage: 45,
      createdAt: new Date('2026-06-10T10:00:00Z').toISOString()
    },
    {
      id: 'prj-beta',
      name: 'Mobile Application Core API',
      description: 'Building secure, scalable, and high-performance backend REST services and JWT auth channels supporting iOS/Android mobile clients.',
      startDate: '2026-07-01',
      endDate: '2026-09-30',
      status: ProjectStatus.IN_PROGRESS,
      managerId: 'usr-pm',
      progressPercentage: 20,
      createdAt: new Date('2026-06-25T11:00:00Z').toISOString()
    },
    {
      id: 'prj-gamma',
      name: 'Enterprise Audit Readiness',
      description: 'System documentation, security controls audit, policy drafting, and credential verification procedures.',
      startDate: '2026-08-01',
      endDate: '2026-10-15',
      status: ProjectStatus.PLANNING,
      managerId: 'usr-pm',
      progressPercentage: 0,
      createdAt: new Date('2026-07-01T15:30:00Z').toISOString()
    }
  ];

  const projectMembers: ProjectMember[] = [
    { projectId: 'prj-alpha', userId: 'usr-alice' },
    { projectId: 'prj-alpha', userId: 'usr-bob' },
    { projectId: 'prj-beta', userId: 'usr-bob' },
    { projectId: 'prj-beta', userId: 'usr-charlie' }
  ];

  const tasks: Task[] = [
    {
      id: 'tsk-1',
      title: 'Design high-fidelity UI landing page mockups',
      description: 'Create modern visual layouts for the desktop and mobile landing pages focusing on conversion rate optimization and clean spacing.',
      status: TaskStatus.COMPLETED,
      priority: TaskPriority.HIGH,
      assignedUserId: 'usr-alice',
      projectId: 'prj-alpha',
      startDate: '2026-06-16',
      dueDate: '2026-06-30',
      estimatedHours: 24,
      createdById: 'usr-pm',
      updatedById: 'usr-pm',
      createdAt: new Date('2026-06-15T12:00:00Z').toISOString(),
      updatedAt: new Date('2026-06-30T17:00:00Z').toISOString()
    },
    {
      id: 'tsk-2',
      title: 'Implement responsive React storefront layouts',
      description: 'Translate approved designs into pixel-perfect React components using Tailwind CSS utility classes and motion animations.',
      status: TaskStatus.IN_PROGRESS,
      priority: TaskPriority.CRITICAL,
      assignedUserId: 'usr-alice',
      projectId: 'prj-alpha',
      startDate: '2026-07-01',
      dueDate: '2026-07-25',
      estimatedHours: 40,
      createdById: 'usr-pm',
      updatedById: 'usr-alice',
      createdAt: new Date('2026-06-15T12:30:00Z').toISOString(),
      updatedAt: new Date('2026-07-05T14:15:00Z').toISOString()
    },
    {
      id: 'tsk-3',
      title: 'Develop database schema and migrations',
      description: 'Create proper relational tables for cart, orders, and payment records. Prepare and test rollback scripts.',
      status: TaskStatus.COMPLETED,
      priority: TaskPriority.MEDIUM,
      assignedUserId: 'usr-bob',
      projectId: 'prj-alpha',
      startDate: '2026-06-18',
      dueDate: '2026-07-05',
      estimatedHours: 16,
      createdById: 'usr-pm',
      updatedById: 'usr-bob',
      createdAt: new Date('2026-06-15T13:00:00Z').toISOString(),
      updatedAt: new Date('2026-07-04T16:00:00Z').toISOString()
    },
    {
      id: 'tsk-4',
      title: 'Integrate Express server & token authorization',
      description: 'Set up modular routers and robust middleware to extract, decrypt, and authorize secure incoming JWT header tokens.',
      status: TaskStatus.IN_PROGRESS,
      priority: TaskPriority.CRITICAL,
      assignedUserId: 'usr-bob',
      projectId: 'prj-beta',
      startDate: '2026-07-02',
      dueDate: '2026-07-20',
      estimatedHours: 32,
      createdById: 'usr-pm',
      updatedById: 'usr-bob',
      createdAt: new Date('2026-06-26T10:00:00Z').toISOString(),
      updatedAt: new Date('2026-07-03T09:00:00Z').toISOString()
    },
    {
      id: 'tsk-5',
      title: 'Establish cloud database connection pooling',
      description: 'Configure stable connection limits, auto-reconnect logic, and SSL handshake validation for production-readiness.',
      status: TaskStatus.PENDING,
      priority: TaskPriority.HIGH,
      assignedUserId: 'usr-charlie',
      projectId: 'prj-beta',
      startDate: '2026-07-15',
      dueDate: '2026-08-10',
      estimatedHours: 20,
      createdById: 'usr-pm',
      updatedById: 'usr-pm',
      createdAt: new Date('2026-06-26T11:00:00Z').toISOString(),
      updatedAt: new Date('2026-06-26T11:00:00Z').toISOString()
    },
    {
      id: 'tsk-6',
      title: 'Draft enterprise visual policy logs',
      description: 'Prepare detailed, clear compliance paperwork, verify access restriction records, and draft emergency backup standards.',
      status: TaskStatus.ON_HOLD,
      priority: TaskPriority.LOW,
      assignedUserId: 'usr-charlie',
      projectId: 'prj-gamma',
      startDate: '2026-08-05',
      dueDate: '2026-08-25',
      estimatedHours: 12,
      createdById: 'usr-pm',
      updatedById: 'usr-pm',
      createdAt: new Date('2026-07-01T16:00:00Z').toISOString(),
      updatedAt: new Date('2026-07-01T16:00:00Z').toISOString()
    }
  ];

  const taskComments: TaskComment[] = [
    {
      id: 'cmt-1',
      taskId: 'tsk-2',
      userId: 'usr-pm',
      userFullName: 'Sarah Jenkins',
      role: UserRole.PROJECT_MANAGER,
      comment: 'Excellent progress on the landing page layout. Alice, please verify the mobile visual responsive boundaries as well.',
      createdAt: new Date('2026-07-03T15:00:00Z').toISOString()
    },
    {
      id: 'cmt-2',
      taskId: 'tsk-2',
      userId: 'usr-alice',
      userFullName: 'Alice Smith',
      role: UserRole.TEAM_MEMBER,
      comment: 'Thanks, Sarah! Checked on mobile. Standard breakpoints are working cleanly. I will now tackle the custom animation details.',
      createdAt: new Date('2026-07-04T10:30:00Z').toISOString()
    },
    {
      id: 'cmt-3',
      taskId: 'tsk-4',
      userId: 'usr-bob',
      userFullName: 'Bob Jones',
      role: UserRole.TEAM_MEMBER,
      comment: 'JWT middleware logic is complete. I am currently adding automatic token refreshes and handling expired states smoothly.',
      createdAt: new Date('2026-07-08T16:00:00Z').toISOString()
    }
  ];

  const taskAttachments: TaskAttachment[] = [
    {
      id: 'att-1',
      taskId: 'tsk-1',
      userId: 'usr-pm',
      fileName: 'landing_wireframe.pdf',
      fileType: 'application/pdf',
      fileSize: 1250000,
      fileUrl: '/uploads/landing_wireframe.pdf',
      createdAt: new Date('2026-06-15T14:00:00Z').toISOString()
    }
  ];

  const notifications: Notification[] = [
    {
      id: 'notif-1',
      userId: 'usr-alice',
      message: 'You have been assigned to task: Design high-fidelity UI landing page mockups',
      type: 'TaskAssigned',
      isRead: true,
      createdAt: new Date('2026-06-15T12:01:00Z').toISOString()
    },
    {
      id: 'notif-2',
      userId: 'usr-alice',
      message: 'You have been assigned to task: Implement responsive React storefront layouts',
      type: 'TaskAssigned',
      isRead: false,
      createdAt: new Date('2026-06-15T12:31:00Z').toISOString()
    },
    {
      id: 'notif-3',
      userId: 'usr-bob',
      message: 'You have been assigned to task: Integrate Express server & token authorization',
      type: 'TaskAssigned',
      isRead: false,
      createdAt: new Date('2026-06-26T10:01:00Z').toISOString()
    }
  ];

  const activityLogs: ActivityLog[] = [
    {
      id: 'act-1',
      userId: 'usr-pm',
      userFullName: 'Sarah Jenkins',
      action: 'Project Created',
      details: 'Created a new project: E-Commerce Platform Redesign',
      createdAt: new Date('2026-06-10T10:00:00Z').toISOString()
    },
    {
      id: 'act-2',
      userId: 'usr-pm',
      userFullName: 'Sarah Jenkins',
      action: 'Task Created',
      details: 'Created task: Design high-fidelity UI landing page mockups for E-Commerce Platform Redesign',
      createdAt: new Date('2026-06-15T12:00:00Z').toISOString()
    },
    {
      id: 'act-3',
      userId: 'usr-alice',
      userFullName: 'Alice Smith',
      action: 'Task Status Updated',
      details: 'Updated task "Design high-fidelity UI landing page mockups" status to Completed',
      createdAt: new Date('2026-06-30T17:00:00Z').toISOString()
    },
    {
      id: 'act-4',
      userId: 'usr-admin',
      userFullName: 'Chief Administrator',
      action: 'User Role Update',
      details: 'Assigned Sarah Jenkins to Project Manager role',
      createdAt: new Date('2026-07-02T11:00:00Z').toISOString()
    }
  ];

  return {
    users,
    passwords,
    projects,
    projectMembers,
    tasks,
    taskComments,
    taskAttachments,
    notifications,
    activityLogs
  };
};

class Database {
  private schema: Schema;

  constructor() {
    this.schema = getInitialSchema();
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(DB_FILE)) {
        const data = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(data);
        // Clean merge with fallback to initial structure to preserve integrity
        this.schema = {
          users: parsed.users || [],
          passwords: parsed.passwords || {},
          projects: parsed.projects || [],
          projectMembers: parsed.projectMembers || [],
          tasks: parsed.tasks || [],
          taskComments: parsed.taskComments || [],
          taskAttachments: parsed.taskAttachments || [],
          notifications: parsed.notifications || [],
          activityLogs: parsed.activityLogs || []
        };
      } else {
        this.save();
      }
    } catch (e) {
      console.error('Error reading database file, using fallback', e);
      this.save();
    }
  }

  private save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.schema, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error writing database file', e);
    }
  }

  // --- Users API ---
  getUsers(): User[] {
    return this.schema.users;
  }

  getUserById(id: string): User | undefined {
    return this.schema.users.find(u => u.id === id);
  }

  getUserByEmail(email: string): User | undefined {
    return this.schema.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  getPasswordHash(userId: string): string | undefined {
    return this.schema.passwords[userId];
  }

  addUser(user: Omit<User, 'id' | 'createdAt'>, passwordHash: string): User {
    const id = `usr-${Math.random().toString(36).substr(2, 9)}`;
    const newUser: User = {
      ...user,
      id,
      createdAt: new Date().toISOString()
    };
    this.schema.users.push(newUser);
    this.schema.passwords[id] = passwordHash;
    this.save();
    return newUser;
  }

  updateUser(id: string, updates: Partial<Omit<User, 'id' | 'createdAt'>>, newPasswordHash?: string): User | undefined {
    const userIndex = this.schema.users.findIndex(u => u.id === id);
    if (userIndex === -1) return undefined;

    const currentUser = this.schema.users[userIndex];
    const updatedUser = {
      ...currentUser,
      ...updates
    };
    this.schema.users[userIndex] = updatedUser;

    if (newPasswordHash) {
      this.schema.passwords[id] = newPasswordHash;
    }

    this.save();
    return updatedUser;
  }

  deleteUser(id: string): boolean {
    const userIndex = this.schema.users.findIndex(u => u.id === id);
    if (userIndex === -1) return false;

    this.schema.users.splice(userIndex, 1);
    delete this.schema.passwords[id];
    
    // Cascading cleanups
    this.schema.projectMembers = this.schema.projectMembers.filter(m => m.userId !== id);
    this.schema.tasks = this.schema.tasks.map(t => {
      if (t.assignedUserId === id) {
        return { ...t, assignedUserId: '' };
      }
      return t;
    });

    this.save();
    return true;
  }

  // --- Projects API ---
  getProjects(): Project[] {
    return this.schema.projects;
  }

  getProjectById(id: string): Project | undefined {
    return this.schema.projects.find(p => p.id === id);
  }

  addProject(project: Omit<Project, 'id' | 'createdAt' | 'progressPercentage'>): Project {
    const id = `prj-${Math.random().toString(36).substr(2, 9)}`;
    const newProject: Project = {
      ...project,
      id,
      progressPercentage: 0,
      createdAt: new Date().toISOString()
    };
    this.schema.projects.push(newProject);
    this.save();
    return newProject;
  }

  updateProject(id: string, updates: Partial<Omit<Project, 'id' | 'createdAt'>>): Project | undefined {
    const index = this.schema.projects.findIndex(p => p.id === id);
    if (index === -1) return undefined;

    const current = this.schema.projects[index];
    const updated = {
      ...current,
      ...updates
    };
    this.schema.projects[index] = updated;
    this.save();
    return updated;
  }

  deleteProject(id: string): boolean {
    const index = this.schema.projects.findIndex(p => p.id === id);
    if (index === -1) return false;

    this.schema.projects.splice(index, 1);

    // Cascading deletions
    this.schema.projectMembers = this.schema.projectMembers.filter(m => m.projectId !== id);
    
    const projectTaskIds = this.schema.tasks.filter(t => t.projectId === id).map(t => t.id);
    this.schema.tasks = this.schema.tasks.filter(t => t.projectId !== id);
    this.schema.taskComments = this.schema.taskComments.filter(c => !projectTaskIds.includes(c.taskId));
    this.schema.taskAttachments = this.schema.taskAttachments.filter(a => !projectTaskIds.includes(a.taskId));

    this.save();
    return true;
  }

  recalculateProjectProgress(projectId: string) {
    const projectTasks = this.schema.tasks.filter(t => t.projectId === projectId);
    if (projectTasks.length === 0) {
      this.updateProject(projectId, { progressPercentage: 0 });
      return;
    }

    const completed = projectTasks.filter(t => t.status === TaskStatus.COMPLETED).length;
    const progress = Math.round((completed / projectTasks.length) * 100);
    this.updateProject(projectId, { progressPercentage: progress });
  }

  // --- Project Members API ---
  getProjectMembers(projectId: string): string[] {
    return this.schema.projectMembers
      .filter(m => m.projectId === projectId)
      .map(m => m.userId);
  }

  setProjectMembers(projectId: string, userIds: string[]) {
    // Clear existing
    this.schema.projectMembers = this.schema.projectMembers.filter(m => m.projectId !== projectId);
    // Add new
    userIds.forEach(userId => {
      this.schema.projectMembers.push({ projectId, userId });
    });
    this.save();
  }

  // --- Tasks API ---
  getTasks(): Task[] {
    return this.schema.tasks;
  }

  getTaskById(id: string): Task | undefined {
    return this.schema.tasks.find(t => t.id === id);
  }

  addTask(task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>): Task {
    const id = `tsk-${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();
    const newTask: Task = {
      ...task,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.schema.tasks.push(newTask);
    this.save();

    this.recalculateProjectProgress(task.projectId);
    return newTask;
  }

  updateTask(id: string, updates: Partial<Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'projectId'>>): Task | undefined {
    const index = this.schema.tasks.findIndex(t => t.id === id);
    if (index === -1) return undefined;

    const current = this.schema.tasks[index];
    const updated = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.schema.tasks[index] = updated;
    this.save();

    this.recalculateProjectProgress(current.projectId);
    return updated;
  }

  deleteTask(id: string): boolean {
    const index = this.schema.tasks.findIndex(t => t.id === id);
    if (index === -1) return false;

    const projectId = this.schema.tasks[index].projectId;
    this.schema.tasks.splice(index, 1);

    // Clean comments and attachments
    this.schema.taskComments = this.schema.taskComments.filter(c => c.taskId !== id);
    this.schema.taskAttachments = this.schema.taskAttachments.filter(a => a.taskId !== id);

    this.save();
    this.recalculateProjectProgress(projectId);
    return true;
  }

  // --- Task Comments API ---
  getTaskComments(taskId: string): TaskComment[] {
    return this.schema.taskComments.filter(c => c.taskId === taskId);
  }

  addTaskComment(taskId: string, userId: string, comment: string): TaskComment | undefined {
    const user = this.getUserById(userId);
    if (!user) return undefined;

    const newComment: TaskComment = {
      id: `cmt-${Math.random().toString(36).substr(2, 9)}`,
      taskId,
      userId,
      userFullName: user.fullName,
      role: user.role,
      comment,
      createdAt: new Date().toISOString()
    };

    this.schema.taskComments.push(newComment);
    this.save();
    return newComment;
  }

  // --- Task Attachments API ---
  getTaskAttachments(taskId: string): TaskAttachment[] {
    return this.schema.taskAttachments.filter(a => a.taskId === taskId);
  }

  addTaskAttachment(taskId: string, userId: string, fileName: string, fileType: string, fileSize: number, fileUrl: string): TaskAttachment {
    const newAttachment: TaskAttachment = {
      id: `att-${Math.random().toString(36).substr(2, 9)}`,
      taskId,
      userId,
      fileName,
      fileType,
      fileSize,
      fileUrl,
      createdAt: new Date().toISOString()
    };

    this.schema.taskAttachments.push(newAttachment);
    this.save();
    return newAttachment;
  }

  // --- Notifications API ---
  getNotificationsForUser(userId: string): Notification[] {
    return this.schema.notifications
      .filter(n => n.userId === userId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  addNotification(userId: string, message: string, type: Notification['type']): Notification {
    const newNotif: Notification = {
      id: `notif-${Math.random().toString(36).substr(2, 9)}`,
      userId,
      message,
      type,
      isRead: false,
      createdAt: new Date().toISOString()
    };

    this.schema.notifications.push(newNotif);
    this.save();
    return newNotif;
  }

  markNotificationRead(id: string, userId: string): boolean {
    const notif = this.schema.notifications.find(n => n.id === id && n.userId === userId);
    if (!notif) return false;
    notif.isRead = true;
    this.save();
    return true;
  }

  markAllNotificationsRead(userId: string) {
    this.schema.notifications.forEach(n => {
      if (n.userId === userId) {
        n.isRead = true;
      }
    });
    this.save();
  }

  // --- Activity Logs API ---
  getActivityLogs(): ActivityLog[] {
    return this.schema.activityLogs.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  addActivityLog(userId: string, action: string, details: string): ActivityLog {
    const user = this.getUserById(userId);
    const userFullName = user ? user.fullName : 'System / Unknown';
    
    const log: ActivityLog = {
      id: `act-${Math.random().toString(36).substr(2, 9)}`,
      userId,
      userFullName,
      action,
      details,
      createdAt: new Date().toISOString()
    };

    this.schema.activityLogs.push(log);
    
    // Limit log size to keep database.json sleek (keep latest 500 logs)
    if (this.schema.activityLogs.length > 500) {
      this.schema.activityLogs = this.schema.activityLogs
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
        .slice(0, 500);
    }

    this.save();
    return log;
  }

  // --- Reporting & Stats API ---
  getDashboardStats(role: UserRole, userId: string): DashboardStats {
    const totalUsers = this.schema.users.length;
    const allProjects = this.schema.projects;
    const allTasks = this.schema.tasks;

    let targetProjects = allProjects;
    let targetTasks = allTasks;

    if (role === UserRole.PROJECT_MANAGER) {
      // PM sees projects they manage
      targetProjects = allProjects.filter(p => p.managerId === userId);
      const prjIds = targetProjects.map(p => p.id);
      targetTasks = allTasks.filter(t => prjIds.includes(t.projectId));
    } else if (role === UserRole.TEAM_MEMBER) {
      // Member sees projects they are member of, or tasks assigned to them
      const prjIds = this.schema.projectMembers.filter(m => m.userId === userId).map(m => m.projectId);
      targetProjects = allProjects.filter(p => prjIds.includes(p.id));
      targetTasks = allTasks.filter(t => t.assignedUserId === userId || prjIds.includes(t.projectId));
    }

    const totalProjects = targetProjects.length;
    const totalTasks = targetTasks.length;

    const completedTasks = targetTasks.filter(t => t.status === TaskStatus.COMPLETED).length;
    const pendingTasks = targetTasks.filter(t => t.status === TaskStatus.PENDING).length;
    const inProgressTasks = targetTasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length;
    const onHoldTasks = targetTasks.filter(t => t.status === TaskStatus.ON_HOLD).length;

    const activeProjects = targetProjects.filter(p => p.status === ProjectStatus.IN_PROGRESS || p.status === ProjectStatus.PLANNING).length;
    const completedProjects = targetProjects.filter(p => p.status === ProjectStatus.COMPLETED).length;

    return {
      totalUsers,
      totalProjects,
      totalTasks,
      completedTasks,
      pendingTasks,
      inProgressTasks,
      onHoldTasks,
      activeProjects,
      completedProjects
    };
  }
}

export const db = new Database();
